from django.contrib import admin
from myapp.models import SubmitWaste,CollectWaste

admin.site.register(SubmitWaste)
admin.site.register(CollectWaste)
